For installation use Open IV

**MODS REQUIRED TO ALL WORK FINE**

Bike Model BMW S1000RR By Zenimo: https://pt.gta5-mods.com/vehicles/2020-bmw-s1000rr-addon-livery-tuning

----------------------------------------------------------------------------------------------------------

How to instal:

------------------------------------------------------------------------------
1: copy the handling.meta file and paste inside the folder

go to: \GTAV\mods\update\dlcpacks\s1000rr\dlc.rpf/data


------------------------------------------------------------------------------

I hope you like :)